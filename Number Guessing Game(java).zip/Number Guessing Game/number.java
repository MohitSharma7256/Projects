import java.util.Random;
import java.util.Scanner;

public class number {

    public static void main(String[] args) {
        Random random = new Random();
        int rightGuess = random.nextInt(100) + 1; // Adding 1 to generate a number between 1 to 100
        int turns = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Guess a number between 1 to 100. You will have 10 turns!");
        System.out.println("Best of luck!");

        int guess;

        boolean win = false;
        while (!win && turns < 10) {
            guess = scanner.nextInt();
            turns++;

            if (guess == rightGuess) {
                win = true;
            } else if (turns == 10) {
                System.out.println("You lose! The right answer was: " + rightGuess);
            } else if (guess < rightGuess) {
                System.out.println("Your guess is lower than the right guess! Turns left: " + (10 - turns));
            } else if (guess > rightGuess) {
                System.out.println("Your guess is higher than the right guess! Turns left: " + (10 - turns));
            }
        }

        if (win) {
            System.out.println("You win!");
        } else {
            System.out.println("You lose!");
        }
        System.out.println("The number was " + rightGuess);
        System.out.println("You used " + turns + " turns to guess the right number");
        System.out.println("Your score is " + ((11 - turns) * 10) + " out of 100");

        scanner.close(); // Close the scanner to prevent resource leak
    }
}
